from .base_model import xFuserModelBaseWrapper

__all__ = [
    "xFuserModelBaseWrapper"
]